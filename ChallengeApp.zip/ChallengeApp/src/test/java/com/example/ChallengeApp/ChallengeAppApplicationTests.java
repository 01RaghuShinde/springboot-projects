package com.example.ChallengeApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
